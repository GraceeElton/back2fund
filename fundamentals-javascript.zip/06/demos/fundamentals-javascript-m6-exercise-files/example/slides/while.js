// While Loop
let x = 10;
while(x > 0) {
console.log(x);
--x;
} 
// 10, 9, 8, 7, 6, 5, 4, 3, 2, 1