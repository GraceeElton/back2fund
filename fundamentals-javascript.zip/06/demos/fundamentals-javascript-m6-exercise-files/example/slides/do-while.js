// Do-while Loop
let x = 10;
do {
console.log(x);
--x;
} while(x > 0);
// 10, 9, 8, 7, 6, 5, 4, 3, 2, 1