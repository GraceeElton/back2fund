// Assignment
let x = "This is a string";
let y = 42;
let z = false;
let date = new Date("January 1, 2023");

// Mathematical Assignment
let val1 = 3;
val1 += 6; // Same thing as val1 = val1 + 6;
console.log(`val1: ${val1}`);

let val2 = 2;
val2 -= 1;
console.log(`val2: ${val2}`);

let val3 = 6;
val3 *= 2;
console.log(`val3: ${val3}`);

let val4 = 10;
val4 /= 5;
console.log(`val4: ${val4}`);

let val5 = 2;
val5 **= 3;
console.log(`val5: ${val5}`);

let val6 = 21;
val6 %= 8;
console.log(`val6: ${val6}`);

// Assignment with increment and decrement operators
let val7 = 10;
let val8 = val7++;
console.log(`val7: ${val7} val8: ${val8}`);

let val9 = 10;
let val10 = --val9;
console.log(`val9: ${val9} val10: ${val10}`);
