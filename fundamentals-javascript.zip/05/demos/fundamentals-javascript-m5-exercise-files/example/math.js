// Addition
let val1 = 3 + 2;
console.log(`val1: ${val1}`);
let val2 = 2 + -1;
console.log(`val2: ${val2}`);

// Subtraction
let val3 = 3 - 1;
console.log(`val3: ${val3}`);
let val4 = 1 - -1;
console.log(`val4: ${val4}`);

// Division
let val5 = 3 / 1;
console.log(`val5: ${val5}`);
let val6 = 21 / 9;
console.log(`val6: ${val6}`);

// Multiplication
let val7 = 3 * 2;
console.log(`val7: ${val7}`);
let val8 = 3 * 3;
console.log(`val8: ${val8}`);

// Remainder
let val9 = 9 % 2;
console.log(`val9: ${val9}`);
let val10 = -10 % 7;
console.log(`val10: ${val10}`);

// Exponentiation
let val11 = 3 ** 2;
console.log(`val11: ${val11}`);
let val12 = 2 ** -1;
console.log(`val12: ${val12}`);

// Increment and decrement
let val13 = 1;
++val13;
console.log(`val13: ${val13}`);

let val14 = 1;
--val14;
console.log(`val14: ${val14}`);
