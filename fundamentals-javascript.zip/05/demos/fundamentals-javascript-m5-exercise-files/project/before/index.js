import createPrompt from 'prompt-sync';
let prompt = createPrompt();
