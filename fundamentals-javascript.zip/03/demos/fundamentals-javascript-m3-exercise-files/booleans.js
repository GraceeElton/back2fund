// Defining booleans
let trueValue = true;
console.log(trueValue);
let falseValue = false;
console.log(falseValue);

// Using the NOT operator with Booleans
let notTrue = !true;
console.log(notTrue);
let notFalse = !false;
console.log(notFalse);
