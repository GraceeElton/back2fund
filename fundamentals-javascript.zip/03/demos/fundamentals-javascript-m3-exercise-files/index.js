console.log("Hi");

console.log("1");
console.log("2");
console.log("3");

let firstName = "David";