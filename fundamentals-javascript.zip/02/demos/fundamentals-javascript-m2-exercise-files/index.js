let firstName = "David";
let lastName = "Tucker";

console.log(`Hello ${firstName} ${lastName}`);